/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import model.Employee;

/**
 *
 * @author KEDS
 */
public class EmployeeController extends AbstractController {

    public EmployeeController() {
    }
    
    protected ModelAndView handleRequestInternal(
            HttpServletRequest request, 
            HttpServletResponse response) throws Exception {
            ModelAndView mv = new ModelAndView();
            if(request.getParameter("submit")!=null){
              String id = request.getParameter("t1");
              String Name = request.getParameter("t2");
              String salary = request.getParameter("t3");

              model.Employee ob = new model.Employee();
              ob.setId(Integer.parseInt(id));
              ob.setName(Name);
              ob.setSalary(Integer.parseInt(salary));

              try{
                 Class.forName("com.mysql.jdbc.Driver");
                 Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/keds", "root", "Rizi_2176");
                 Statement st = cn.createStatement();
                 String query = "insert into employee values('"+ob.getId()+"','"+ob.getName()+"','"+ob.getSalary()+"')";
                int re = st.executeUpdate(query);
                if(re>0){
                   mv.addObject("msg","Save successsful");
                }

              }
              catch(Exception ex){
                mv.addObject("msg","Error: " +ex);
              }
            }

           /* try{
                 Class.forName("com.mysql.jdbc.Driver");
                 Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee", "root", "");
                 Statement st = cn.createStatement();
                 String query = "select * from ";
                ResultSet rs = st.executeQuery(query);
                List<Employee> li = new ArrayList();

              }
              catch(Exception ex){
                mv.addObject("msg","Error: " +ex);
              }


*/


            return mv;
    }

}