/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

/**
 *
 * @author KEDS
 */
public class StudentController extends AbstractController {

    public StudentController() {
    }
    
    protected ModelAndView handleRequestInternal(
            HttpServletRequest request, 
            HttpServletResponse response) throws Exception {
            ModelAndView mv = new ModelAndView();
            mv.addObject("heading", "Student List");
            mv.addObject("r", 25);
            mv.addObject("n", "Riziki Ally");
            mv.addObject("c", "Java");
            
            return mv;
    }

}